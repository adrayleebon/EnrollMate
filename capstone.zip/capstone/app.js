const express = require('express');
const app = express();
const mysql = require('mysql');
const path = require('path');

// Set EJS as the templating engine
app.set("view engine", "ejs");
app.set('views', path.join(__dirname, 'views'));

// Static files
app.use(express.static("public"));

// Parsing data/application
const bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Database connection
const conn = require('./conn.js');

// Route handlers
app.get('/index', (req, res) => {
    res.render('index');
});

// Route handler for the dashboard
app.get('/dashboard', (req, res) => {
    const getdata = "SELECT * FROM students";
    conn.query(getdata, (err, mydata) => {
        if (err) throw err;
        res.render('dashboard', {
            action: 'list',
            sampledata: mydata
        });
    });
});

// Root route
app.get('/', (req, res) => {
    const getdata = "SELECT * FROM students";
    conn.query(getdata, (err, mydata) => {
        if (err) throw err;
        res.render('index', {
            title: "Node",
            action: 'list',
            sampledata: mydata
        });
    });
});

// Add student route
app.post('/addstudent', (req, res) => {
    const { id_num, fullname, phone, email, date } = req.body;

    const sql = `INSERT INTO students (id_num, fullname, phone, email, date) VALUES (?, ?, ?, ?, ?)`;
    conn.query(sql, [id_num, fullname, phone, email, date], (err, result) => {
        if (err) throw err;
        console.log('New Record Inserted');
        res.send(`
            <script>
            alert("1 student Added successfully!");
            window.location.href="/";
            </script>
        `);
    });
});

// Delete data route
app.get('/delete/:id', (req, res) => {
    const del_id = req.params.id; // Ensure this matches the ID used in your database
    const toDelete = `DELETE FROM students WHERE ID = ?`; // Ensure this ID matches your database schema
    conn.query(toDelete, [del_id], (err, result) => {
        if (err) throw err;
        console.log("Data is Deleted!");
        res.send(`
            <script>
            alert("1 Data is Deleted!");
            window.location.href="/";
            </script>
        `);
    });
});

// Update student route
app.post('/updatestudent/:id', (req, res) => {
    const up_id = req.params.id; // This should match the ID used in your database
    const { id_num, fullname, phone, email, date } = req.body;

    const update = `UPDATE students 
    SET id_num = ?, 
    fullname = ?, 
    phone = ?, 
    email = ?, 
    date = ? 
    WHERE ID = ?`; // Ensure this uses the correct ID field
    conn.query(update, [id_num, fullname, phone, email, date, up_id], (err, result) => {
        if (err) throw err;
        res.send(`
            <script>
            alert("Data Updated Successfully!");
            window.location.href="/";
            </script>
        `);
    });
});

// Start the server
app.listen(4000, () => {
    console.log("Listening at port 4000...");
});